# SOEN - Collaborative Development Environment
## Interview Preparation Guide (Hinglish)

SOEN ek real-time collaborative development environment (IDE) hai. Iski madad se multiple developers ek saath real-time me code write aur edit kar sakte hain, chat kar sakte hain, AI se help le sakte hain (`@ai` mention karke), aur code ko direct browser ke andar execute karke live preview dekh sakte hain (jaise CodeSandbox ya StackBlitz me hota hai).

---

## 🏗️ Project Architecture (Mermaid Diagram)

```mermaid
graph TD
    Client[React Frontend] <-->|Socket.IO: Live Chat, Sync| Server[Node.js / Express Server]
    Client <-->|HTTP API: Auth, Projects| Server
    Client -->|Local Sandboxing| WebContainer[WebContainer API - Browser Runtime]
    Server -->|Generate Code / Chat| Gemini[Google Gemini AI]
    Server -->|Session Blacklist| Redis[Redis DB]
    Server -->|User & Project Data| MongoDB[(MongoDB Database)]
```

---

## 🛠️ Tech Stack & "Kyun Use Kiya?" (Why this stack?)

| Tech Component | What is it? | Why did we use it? (Interview Pitch) |
| :--- | :--- | :--- |
| **React.js** | Frontend Framework | Dynamic UI rendering, state management (for editor & file tree), and clean component lifecycle. |
| **WebContainer API** | Browser-based Web Sandbox | **USP (Unique Selling Proposition):** Browser ke andar hi micro-operating system/Node runtime chala deta hai. `npm install` and `npm start` user ke machine par nahi, browser ke secure environment me bina backend server cost ke chalta hai. |
| **Socket.IO** | Bi-directional WebSockets | Real-time chat aur multi-user editor syncing ensure karne ke liye. Rooms setup kiye hain project-wise taaki users isolated groups me kaam karein. |
| **Node.js & Express** | Backend Server | Scalable backend built with asynchronous event-driven structure. API routes and middleware handle karta hai. |
| **MongoDB & Mongoose** | NoSQL Database | Projects ki files directory dynamic/nested ho sakti hain (`Mixed` Schema Type), jo flexible document model ke liye best suitable hai. |
| **Redis** | In-memory Cache/DB | **Token Blacklisting (Logout):** JWT stateless session invalidation ke liye. Jab user logout karega, uska active JWT Redis me `EX` (Expiration) duration ke sath save ho jata hai. API request check karegi agar token blacklisted hai toh reject karegi. |
| **Google Gemini AI** | Generative AI Service | Code generation aur prompt assistance (`@ai` integration) ke liye. `gemini-2.5-flash` model use kiya hai for fast JSON formatting. |

---

## 🔄 Core Workflows Explained (Asan Bhasha Me)

### 1. User & Project Management Flow
- User register karta hai with email & password (hashed via `bcrypt` inside [user.model.js](file:///d:/Coding/Projects/Self%20Projects/SOEN/backend/models/user.model.js)).
- Login hone par server use ek **JWT** token return karta hai.
- User ek naya Project create kar sakta hai ya collaborators select karke `/projects/add-user` API ke throw unhe add kar sakta hai.

### 2. Socket Connection & Collaborative Room Flow
- Jab user kisi project dashboard par jata hai, toh frontend server ke sath websocket connection initialize karta hai (inside [socket.jsx](file:///d:/Coding/Projects/Self%20Projects/SOEN/frontend/src/config/socket.jsx)).
- Sockets connect hone par ek Custom Middleware auth verification karta hai aur user ko Project ID ke corresponding unique room me add (`socket.join(projectId)`) kar deta hai.
- Jab koi user chat message likhta hai ya file tree update karta hai, wo event generic sockets ke throw pure room me propagate hota hai, updates sync ho jate hain.

### 3. AI Code Generation & Auto-mounting (`@ai`)
- Chat input me jab user `@ai` use karta hai (e.g. `@ai create an express app`), toh server use process karta hai.
- AI Service Prompt ko Gemini API ko pass karti hai, system prompt instruction ([ai.service.js](file:///d:/Coding/Projects/Self%20Projects/SOEN/backend/services/ai.service.js)) me rule set hai ki output **strict JSON** hona chahiye with keys: `text`, `fileTree`, `buildCommand`, aur `startCommand`.
- Response incoming hone par React client use parser ke through read karta hai. Agar response me `fileTree` structured data hai, toh frontend automatically use browser based **WebContainer** me mount/inject kar deta hai!

### 4. Running Code via WebContainer (Sandbox Execution)
- Jab user editor panel me "Run" button click karta hai, toh:
  1. Frontend WebContainer instance boot karta hai.
  2. Pure project file tree object ko us web container environment me mount kiya jata hai (`webContainer.mount(fileTree)`).
  3. `webContainer.spawn('npm', ['install'])` execute hota hai dependencies install karne ke liye.
  4. `webContainer.spawn('npm', ['start'])` command start hota hai local server chalane ke liye.
  5. WebContainer automatically event trigger karta hai `server-ready`, jo dynamic internal url block structure provide karta hai (e.g. `http://localhost:5173`).
  6. Frontend use user interfaces me side-by-side iframe ke source set karke display kar deta hai.

---

## 🙋‍♂️ Top 15+ Interview Questions with Expert Answers

### Group A: WebContainers & Sandboxing (USP of the project)

#### Q1. WebContainer API kya hai aur isne backend resource scaling problem ko kaise solve kiya?
* **Answer**: WebContainer API standard WebAssembly (Wasm) runtime hai jo browser ke dynamic stack me safely aur locally full Node.js environment/operating system run kar deta hai. 
* **Scaling Benefit**: Agar hum standard backend server par individual containers (like Docker) load karte, toh har user ke runtime compilation aur start command ke liye hamare cloud server resources (CPU, RAM) exhaust hote aur costly server architecture banana padta. WebContainer load ko fully browser/client machines par offload kar deta hai. Client's browser installs dynamic modules and executes node scripts. Hamara backend server bilkul free aur light rehta hai.

#### Q2. WebContainers boot karne ke liye browser security setup me kya attributes require hote hain?
* **Answer**: WebContainers process isolated SharedArrayBuffers and Web Workers use karte hain. Security context manage karne ke liye hume client server headers headers inject karne padte hain:
  - `Cross-Origin-Embedder-Policy: require-corp`
  - `Cross-Origin-Opener-Policy: same-origin`
  Humne standard [vite.config.js](file:///d:/Coding/Projects/Self%20Projects/SOEN/frontend/vite.config.js#L9-L13) server configuration me ye cross-origin isolation policy enabled ki hai, varna WebContainers boot command crash ho jayega.

#### Q3. WebContainer aur Docker ke containers me kya difference hai?
* **Answer**:
  - **Docker** server-side containerization tool hai jo backend operating system kernel resource levels ko customize aur allocate karta hai.
  - **WebContainer** completely browser-native containerization runtime (sandboxing) hai jo WebAssembly framework base par single browser window space ke resources use karta hai. Isme file changes fast browser system level memory cache me save hote hain.

---

### Group B: WebSockets & Real-Time Sync

#### Q4. Socket.io me room authentication security kaise handle ki hai?
* **Answer**: Humne [server.js](file:///d:/Coding/Projects/Self%20Projects/SOEN/backend/server.js#L33-L62) me custom Socket.IO middleware initialize kiya hai.
  - Jab client connect karta hai toh authorization headers ya auth handshake object me encrypted JWT supply karta hai.
  - Socket.IO middleware database validation call run karta hai project validation verify karne ke liye aur verification process complete hone ke baad next call validation accept karti hai. Agar verification fail hua toh socket handshake reject ho jata hai.

#### Q5. Chat box me `@ai` detection logic real-time messaging pipeline me kaise fit kiya hai?
* **Answer**: Server-side client sockets handle karte hain:
  - Ek websocket connection data trigger events catch karta hai (`project-message`).
  - Agar incoming string package me user `@ai` call detect karta hai, server trigger check karke message standard database logs bypass karke raw prompt service fetch karwata hai AI service se.
  - AI response generic model JSON parameters check karke immediate sockets channel ko direct updates emit/broadcast kar deta hai room runtime me.

#### Q6. Project me multi-user live file editing integration concurrency conflicts kaise resolve karta hai?
* **Answer**: Abhi ke project logic me `onBlur` syntax highlight data state updates local MongoDB call update ke through flow backend push karte hain.
  - *Advanced / Pro answer for interviews*: Agar multiple clients exact same lines concurrently click code edit karenge toh data override status ban sakta hai. Production ready apps handle conflicts using **CRDTs (Conflict-free Replicated Data Types)** or **Operational Transformations (OT)** through packages like **Yjs** or **ShareDB** jo har keystroke trace updates handle karte hain. Real-world upgrades me hum in implementations ko prioritize karenge.

---

### Group C: Backend & Security

#### Q7. JWT token authentication ke sath Logout implementation me Redis ka kya contribution hai?
* **Answer**: JWT tokens stateless hote hain, server-side unka record rakhna compulsory nahi hai, par iska disadvantage hai ki validity timer expire hone se pehle user token validate karke actions trigger kar sakta hai chahe logout call kar diya ho.
  - Is security gap ko fill karne ke liye hum Redis use karte hain for **Token Blacklisting**.
  - Logout trigger API client call processing me user authentication header token collect karta hai, use target blacklist key system base par string index register kar data status store karta hai `redisClient.set(token, 'logout', 'EX', 24 hours)` (refer to [user.controller.js](file:///d:/Coding/Projects/Self%20Projects/SOEN/backend/controllers/user.controller.js#L76)).
  - Middleware authenticate query checks processing time me Redis index verify karti hai, duplicate existence identify hone par request direct return blocks construct blocks clear kar authentication block output throw karti hai.

#### Q8. Database validations ke liye Express Validators ka integration kaise kiya hai?
* **Answer**: Routes configurations me (refer to [user.routes.js](file:///d:/Coding/Projects/Self%20Projects/SOEN/backend/routes/user.routes.js#L8-L18)) parameter validation rules map out kiye gaye hain.
  - API post controllers trigger checks implement valid schemas. Agar details like email syntax dynamic standard constraints follow nahi karengi toh controller request process reject message output return triggers run kar dega.

#### Q9. MongoDB me Project file directory schema kaise construct aur save ho rahi hai?
* **Answer**: Schema definition files nested key trees store records model configure karti hain:
  - Humne [project.model.js](file:///d:/Coding/Projects/Self%20Projects/SOEN/backend/models/project.model.js#L19-L22) schema me `fileTree` data attribute field type `mongoose.Schema.Types.Mixed` define kiya hai.
  - dynamic files structures JSON hierarchy properties follow karti hain (folders/files keys containing properties), is vajah se Mixed structure usage complex multi-level file path nested structures easy handling block output update system optimize karta hai.

---

### Group D: Frontend & Gemini AI API

#### Q10. System Instruction set rules me Gemini model parameters ko deterministic JSON structure format me maintain kaise kiya gaya hai?
* **Answer**: Humne [ai.service.js](file:///d:/Coding/Projects/Self%20Projects/SOEN/backend/services/ai.service.js#L8-L11) model initialization runtime control options adjust kiye hain:
  - Configuration mapping config set parameter `responseMimeType: "application/json"`.
  - System instructions prompt content parameters me rules provide kiye hain standard design formats examples define karke, jisse model validation parameters runtime check output formats strictly standard formats conform karte hain code generation instances structure configurations maintain karte hue.

#### Q11. Highlight.js library contentEditable code area sync me problems create kar sakti hai. Isse local React flow me manage kaise kiya hai?
* **Answer**: Client editor area markup pre/code tags contain karta hai setting content dynamic `dangerouslySetInnerHTML`.
  - React component change syntax update changes track logic process handle updates state blur parameter configurations check karke back save commands perform run karte hain. Component render structure text parameters changes dynamic flow preserve elements output system configurations check logic structure display visual changes highlight structure output clean handle karta hai.

---

## 💡 Quick Tips for your Interview:
1. **Highlight the WebContainer integration first**: Start your intro by saying: *"Maine ek real-time collaborative development environment (IDE) banaya hai, jiska sabse bada feature browser-based micro-compilation system runtime setup hai. Hum custom systems scale offloading local run WebAssembly packages logic implement client runtime system me compile perform karwa rahe hain..."*
2. **Be ready on Redis**: Explain the token blacklisting cleanly. Interviewers love caching/session token management question sets.
3. **Be confident about Gemini structure**: Speak about prompt engineering system instructions design implementations, explaining how you restrict text outputs strictly inside JSON boundaries.
