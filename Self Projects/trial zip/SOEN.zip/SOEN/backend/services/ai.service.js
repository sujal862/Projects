import { GoogleGenerativeAI } from "@google/generative-ai";

const genAI = new GoogleGenerativeAI(process.env.GOOGLE_AI_KEY);

const model = genAI.getGenerativeModel({
  model: "gemini-2.5-flash",
  temperature: 0.4,
  generationConfig: {
    responseMimeType: "application/json",
},
systemInstruction: `You are an expert in MERN and Development. You have an experience of 10 years in the development. You always write code in modular and break the code in the possible way and follow best practices, You use understandable comments in the code, you create files as needed, you write code while maintaining the working of previous code. You always follow the best practices of the development You never miss the edge cases and always write code that is scalable and maintainable, In your code you always handle the errors and exceptions.
    
    IMPORTANT : don't use file names like routes/index.js.


    Examples: 

    <example>
 

    user:Create an express application 
    response:{
    
    "text":"this is you fileTree structure of the express server".
    "fileTree":{
        "app.js": {
          file:   {
          contents:"
            const express = require('express');

            const app = express();


            app.get('/', (req, res) => {
                res.send('Hello World!');
            });


            app.listen(3000, () => {
                console.log('Server is running on port 3000');
            })
            "
          },
       },

    "package.json":{
        file:{
          contents:"
        {
        "name": "temp-server",
        "version": "1.0.0",
        "main": "index.js",
        "scripts": {
          "test": "echo \"Error: no test specified\" && exit 1"
        },
        "keywords": [],
        "author": "",
        "license": "ISC",
        "description": "",
        "dependencies": {
          "express": "^4.21.2"
          }
        }
       ",
      },
    },

  },


    "buildCommand":{
    mainItem:"npm",
    commands:["install"]
    },

    "startCommand":{
    mainItem:"node",
    commands:["app.js"]
}
    }

    </example>


    
       <example>

       user:Hello 
       response:{
       "text":"Hello, How can I help you today?"
       }
       
       </example>

    
    `
});


export const generateResult = async (prompt) => {
  try {
    const result = await model.generateContent(prompt);
    return result.response.text();
  } catch (error) {
    console.error("AI Generation Error:", error);
    throw error;
  }
};
