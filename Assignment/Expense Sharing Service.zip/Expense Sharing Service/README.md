# Expense Sharing Service

A FastAPI backend for the Decentro SDE Intern assignment. Track group expenses,
save equal or custom allocations, inspect pairwise and net balances, record real-world
payments, and generate advisory Smart Settlement Suggestions. INR only; no frontend
or payment gateway is involved.

The supplied PDF's body describes **Expense Sharing Service**, despite its
Payment Retry Orchestrator filename. This implementation follows the document body
and the agreed specification. It is an assignment-sized application, not a claim of
production readiness.

## Assignment coverage

- [x] Create/list users; duplicate display names allowed.
- [x] Create/list groups, add members, list members; duplicate membership rejected.
- [x] Record positive equal expenses and list group history.
- [x] Persist original participant shares; later members do not inherit old expenses.
- [x] Pairwise and per-member net balances scoped to each group.
- [x] Mandatory enhancement: Smart Settlement Suggestions and documented tradeoffs.
- [x] Bonus: partial/full settlements, including simplified routes.
- [x] Bonus: custom allocations to a subset of members.
- [x] Bonus: unit and real-MySQL integration tests, including rollback/concurrency.
- [x] Bonus: Docker/Compose with migrations and readiness checks.
- [x] API documentation, schema explanation, Postman flow, seed demo, interview notes.

No authentication was required. No GitHub publication or assignment submission is
performed by this project. Review the files and publish your repository separately.

## Stack and prerequisites

- Python 3.11 (container: 3.11.14), FastAPI, Pydantic v2, pydantic-settings, Uvicorn.
- SQLAlchemy 2.x async sessions, asyncmy, MySQL 8.4.8/InnoDB, Alembic.
- pytest, pytest-asyncio, HTTPX, Ruff.
- Docker Engine/Desktop with Compose v2 for the simplest setup.
- Optional Node.js/npm for running the Postman collection via Newman.

FastAPI provides typed contracts and interactive documentation. MySQL provides relational
constraints, transactions, consistent snapshots, and row locks. The async driver keeps
database waits asynchronous. Exact direct/transitive Python versions are in
`requirements.txt` and `requirements-dev.txt`; development tools are separate from
the container runtime. Base Python/MySQL images are pinned by version and digest.
No Redis, worker queues, external services, or frontend are needed.

## Run with Docker Compose

From this directory:

```powershell
Copy-Item .env.example .env
docker compose up --build -d --wait api
```

On Linux/macOS, replace the first command with `cp .env.example .env`.
The defaults work without an `.env` too; copying it makes local configuration explicit.
These are synthetic demo credentials. Do not reuse them on a shared deployment.

- API: <http://localhost:8000>
- Swagger UI: <http://localhost:8000/docs>
- ReDoc: <http://localhost:8000/redoc>
- OpenAPI JSON: <http://localhost:8000/openapi.json>
- Liveness: <http://localhost:8000/health>
- Database readiness: <http://localhost:8000/ready>

Compose waits for an authenticated MySQL health check, then runs `alembic upgrade head`
before starting Uvicorn. The API runs as a non-root OS user with no reload mode.
MySQL persists in the `expense-sharing_mysql_data` named volume. Published ports bind
to localhost. MySQL uses **host port 3308**, avoiding a host restriction encountered
on 3306; the internal database port remains 3306. Test MySQL uses host port 3307.

Inspect logs/status:

```powershell
docker compose ps
docker compose logs --tail=100 api
docker compose logs --tail=100 db
```

If a host port is occupied, change `API_PORT` or `MYSQL_PORT` in `.env`. Update the
local `DATABASE_URL` to match the database host port and demo/Postman base URL to match
the API port. The API container uses its own internal `db:3306` URL from Compose.
Changing MySQL credentials or database initialization values does not reinitialize an
existing volume. Use the original credentials or deliberately reset demo data below.

## Run Python locally with MySQL in Docker

Python 3.11 is the tested local version. PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements-dev.txt
Copy-Item .env.example .env
docker compose up -d --wait db
python -m alembic upgrade head
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

If the container API is already running, stop it first with `docker compose stop api`
to free port 8000. Virtual-environment activation is optional: invoke
`.\.venv\Scripts\python.exe` directly if PowerShell execution policy prevents activation.
On Linux/macOS, activate with `source .venv/bin/activate`; other commands are equivalent.
`--reload` can be added for local development only.

### Environment variables

| Variable | Default / purpose |
| --- | --- |
| `DATABASE_URL` | Local Python: `mysql+asyncmy://expense:expense_demo@127.0.0.1:3308/expense_sharing` |
| `MYSQL_DATABASE` | Compose development database: `expense_sharing` |
| `MYSQL_USER` | Compose application database user: `expense` |
| `MYSQL_PASSWORD` | Synthetic demo password: `expense_demo` |
| `MYSQL_ROOT_PASSWORD` | Synthetic initialization password: `root_demo` |
| `MYSQL_PORT` | Development database published port: `3308` |
| `API_PORT` | API published port: `8000` |
| `TEST_DATABASE_URL` | Explicit test connection; never inferred from `DATABASE_URL` |

The application reads `DATABASE_URL` from environment or `.env`, with environment
taking precedence. The remaining `MYSQL_*` values configure Compose, not the Python
settings object. The Compose API derives its URL from the MySQL service variables.
Percent-encode reserved characters in connection-URL credentials. Local `.env` and
`.env.test` are ignored by Git and excluded from Docker build context.

### Migrations

```powershell
# Local Python, using DATABASE_URL/.env
python -m alembic upgrade head
python -m alembic current
python -m alembic check

# Running API container
docker compose exec api python -m alembic current
docker compose exec api python -m alembic check
```

`migrations/versions/0001_initial.py` explicitly creates all tables, constraints, and
indexes. Application startup never calls `create_all`. For a future schema change,
generate/review an Alembic revision before applying it. MySQL DDL may commit partially;
inspect a failed migration before retrying. Single-instance startup migration is a demo
convenience; a multi-instance deployment should use a separate migration step.

## Demo and Postman

Run inside the running container (no local Python dependencies required):

```powershell
docker compose exec api python -m scripts.seed_demo
```

Or with the local virtual environment:

```powershell
python -m scripts.seed_demo --base-url http://localhost:8000
```

Each run **adds** four synthetic users and two groups; it does not erase existing data.
The output prints IDs, balances, suggestions, and recorded payments. The trip group shows:

1. Mohit pays 1200 equally across three original members.
2. Rahul pays 600 equally across the same members.
3. Priya joins; old allocations still have three participants.
4. Ankit pays 300 for Rahul (100) and Priya (200), excluding himself from the custom split.
5. Current net balances: Mohit +600, Rahul −100, Ankit −300, Priya −200.
6. Ankit records a partial payment of 150 to Mohit; balances update accordingly.

The second group shows Mohit owing Rahul 500 and Rahul owing Ankit 500. The single
suggestion is Mohit paying Ankit 500. The script records that full payment and asserts
there are no remaining suggestions. Historical pairwise entries retain a zero-net cycle.

Import both files into Postman, select **Expense Sharing Local**, then run the entire
collection in order:

- `docs/postman/expense-sharing.postman_collection.json`
- `docs/postman/local.postman_environment.json`

The collection captures generated IDs, so it works on a nonempty database. Its 34
requests include response assertions, a late joiner, custom subset, partial settlement,
rejected overpayment, simplified route, and empty final suggestions. It creates fresh
records on each run. Optional CLI execution:

```powershell
npx --yes newman@6.2.1 run docs/postman/expense-sharing.postman_collection.json -e docs/postman/local.postman_environment.json
```

See `docs/interview-notes.md` for a short demonstration walkthrough. No demo video is included.

## API contract

All feature routes use `/api/v1`. The complete request/response schemas and examples
are in `/docs`; see [docs/api-reference.md](docs/api-reference.md) for a concise reference.
Creation returns 201, reads 200. Errors consistently use:

```json
{"error":{"code":"invalid_payer","message":"Payer must be an existing group member","details":null}}
```

404 means missing group/user; 409 means duplicate/conflicting financial state; 422 means
invalid input or business validation; 503 means unavailable database operation/readiness.
Validation details contain location/message/type and omit raw input. Internal SQL,
credentials, and stack traces are not returned to clients.

Growing lists use `?limit=20&offset=0`, with limit 1–100 and offset ≥0. Responses contain
`items`, `limit`, `offset`, `has_more`. Ordering is ascending ID (member lists: user ID).
Balances and suggestions return the entire group state. No global balance endpoint
merges unrelated groups.

Example creation requests (substitute actual generated IDs):

```http
POST /api/v1/users
{"name":"Mohit"}

POST /api/v1/groups
{"name":"Goa Trip"}

POST /api/v1/groups/1/members
{"user_id":1}

POST /api/v1/expenses
{"group_id":1,"paid_by":1,"amount":"100.00","description":"Dinner"}
```

## Architecture

```text
app/
  main.py                 App factory, lifecycle, error handlers, health
  core/                   Environment settings and application errors
  db/                     Base metadata, engine, async session dependency
  models/entities.py      Six relational table mappings
  schemas/contracts.py    Pydantic request/response contracts
  api/routes/v1.py        Thin HTTP handlers
  services/ledger.py      Business rules, explicit transactions and queries
  utils/                  Pure money, allocation, balance and matching functions
migrations/               Versioned Alembic schema
tests/unit/               Pure financial logic, validation, safety guard
tests/integration/        Real MySQL, HTTP API, rollback and concurrency
scripts/                  Container startup, synthetic demo, test URL safety
docs/                     API reference, design decisions, interview notes, Postman
```

Routes delegate business rules to services; services own the transaction. There is no
generic repository framework. Queries are explicit rather than lazy relationships,
keeping async I/O visible. Pure calculations have no dependency on FastAPI or MySQL.

## Database schema

```mermaid
erDiagram
    users ||--o{ group_members : joins
    groups ||--o{ group_members : contains
    groups ||--o{ expenses : records
    users ||--o{ expenses : pays
    expenses ||--|{ expense_splits : allocates
    users ||--o{ expense_splits : participates
    groups ||--o{ settlements : records
    users ||--o{ settlements : sends
    users ||--o{ settlements : receives
    users {
        BIGINT id PK
        VARCHAR name
        DATETIME created_at
    }
    groups {
        BIGINT id PK
        VARCHAR name
        DATETIME created_at
    }
    group_members {
        BIGINT group_id PK,FK
        BIGINT user_id PK,FK
        DATETIME joined_at
    }
    expenses {
        BIGINT id PK
        BIGINT group_id FK
        BIGINT paid_by FK
        BIGINT amount_paise
        VARCHAR description
        VARCHAR split_type
        DATETIME created_at
    }
    expense_splits {
        BIGINT expense_id PK,FK
        BIGINT user_id PK,FK
        BIGINT share_paise
    }
    settlements {
        BIGINT id PK
        BIGINT group_id FK
        BIGINT paid_by FK
        BIGINT paid_to FK
        BIGINT amount_paise
        DATETIME created_at
    }
```

All tables use InnoDB and utf8mb4. Composite membership/split primary keys enforce
uniqueness. RESTRICT foreign keys preserve referenced financial history. Composite
foreign keys require payers and settlement parties to have membership records.
Check constraints enforce amount bounds, split type, and different payment parties.
Expense-share membership and sum equality are enforced atomically in the service.
Group/ID history indexes and user foreign-key indexes support the query paths.
No delete/update API is exposed.

Timestamps are UTC, stored in `DATETIME(6)` without an offset and returned as ISO 8601
UTC with `Z`. Connections explicitly use UTC. Stored shares preserve participants at
creation time; current memberships are consulted only for new expenses.

## Money and splitting

- Store money in BIGINT integer paise: INR 100.50 = 10050 paise.
- Accept only unsigned decimal **strings** with at most two fractional digits.
  Reject JSON numbers, scientific notation, whitespace, NaN/infinity, and extra precision,
  including `"1.000"`. No monetary float arithmetic or silent rounding is used.
- Maximum individual expense/payment/share: INR **1,000,000,000.00**.
  Expenses/payments are positive; custom shares may be zero.
- Return fixed two-decimal strings. Derived net totals may be negative or exceed the
  per-record input ceiling.
- Equal is default: all current members, including the payer. Allocate quotient paise,
  then remaining paise in ascending user ID order. INR 100 across IDs 1, 2, 3 produces
  `33.34`, `33.33`, `33.33`. A one-paisa expense can give some members zero shares.
- Custom: unique participant IDs, group members only, nonnegative shares, at least
  one positive share, and exact sum. A subset is allowed; the payer may be excluded.
- Equal requests must omit `splits` entirely; even explicit `null` is rejected.

Custom example, assuming IDs 1, 2, 3 are members:

```json
{
  "group_id":1,
  "paid_by":1,
  "amount":"1000.00",
  "description":"Hotel custom allocation",
  "split_type":"custom",
  "splits":[
    {"user_id":1,"amount":"500.00"},
    {"user_id":2,"amount":"300.00"},
    {"user_id":3,"amount":"200.00"}
  ]
}
```

## Balances, payments, and suggestions

Pairwise balances sum saved non-payer shares owed to the payer and net opposite
obligations between that same pair. No self-debt is created. Payments add opposite
pairwise entries. IDs and names are explicit; names are never dictionary keys.

For each member:

```text
net = expenses paid − allocated shares + settlements sent − settlements received
```

Positive means should receive; negative means should pay; zero means settled. The
group sum is always zero. Balances are derived from expenses, splits, and settlements;
there is no independent mutable balances table.

A settlement records an already-made real-world payment. It does not move bank money.
Both parties must be different members; sender must have negative net and recipient
positive net. Amount cannot exceed either outstanding net position. Partial payments
are allowed, including between members without a direct original debt.

**Historical pairwise debt and a settlement plan can differ.** If A owes B 500 and B
owes C 500, A may pay C 500. All net positions then become zero. Pairwise entries retain
the zero-net A→B→C→A cycle, but suggestions are empty. Use net positions/suggestions
to decide what remains to pay; do not pay historical cycles again.

Smart suggestions match the largest debtor to the largest creditor, transfer the smaller
remaining amount, and repeat using priority queues. Ties use ascending user ID. This
preserves exact net positions and may change who pays whom. Matching takes **O(n log n)**
time and O(n) space after balances are loaded. It uses at most n−1 transfers for an
unsettled group, but **does not guarantee the mathematically minimum number of payments**
or improvement over every alternative. Suggestions are advisory, never persisted or executed.
The problem solved is practical payment coordination across interconnected debts.

Balance loading uses three group-scoped queries plus group existence, with no N+1
queries. It loads O(members + split rows + settlements) data; this deliberately favors
clear logic for modest groups. Expense history fetches one page plus one batched split query.

## Transactions and consistency

Service methods own explicit transaction boundaries. All group membership/balance writes
lock the group row with `SELECT ... FOR UPDATE` **before** dependent reads. This makes
the membership snapshot stable during expense creation and serializes settlement validation.
Expense and all splits commit together. Failures roll back the whole mutation.

MySQL REPEATABLE READ keeps multi-query balance/suggestion reads consistent. Writers
take their locking read first and establish the ordinary-read snapshot after acquiring
the lock, so a waiting payment sees the previous writer's commit. There are no early
queries in dependencies that would accidentally open a competing transaction/snapshot.
See [docs/design-decisions.md](docs/design-decisions.md) for detailed reasoning.

## Tests and checks

After installing `requirements-dev.txt`:

```powershell
python -m pytest tests/unit -q
python -m ruff check .
python -m ruff format --check .
python -m pip check
```

For real-MySQL integration tests, start the separate disposable service:

```powershell
docker compose --profile test up -d --wait test-db
$env:TEST_DATABASE_URL = 'mysql+asyncmy://expense_test:test_demo@127.0.0.1:3307/expense_sharing_test'
python -m pytest tests/integration -q
# Run everything, including integration tests:
python -m pytest -q
Remove-Item Env:TEST_DATABASE_URL
```

On Linux/macOS:

```bash
export TEST_DATABASE_URL='mysql+asyncmy://expense_test:test_demo@127.0.0.1:3307/expense_sharing_test'
python -m pytest -q
unset TEST_DATABASE_URL
```

The fixture requires this **explicit** URL, driver `mysql+asyncmy`, database exactly
`expense_sharing_test`, username exactly `expense_test`, and a database different from
the configured development database. It migrates only after that guard, then deletes
test rows in foreign-key order before each test. Compose grants the test user access
only to its test database, on a separate ephemeral MySQL service. Do not point it at
valuable data or run parallel test workers against the same test database. Without
`TEST_DATABASE_URL`, integration tests are **skipped**, not passed. An explicitly
configured unreachable test database causes failures rather than silent skips.

Tests cover money validation, deterministic equal/custom allocations, opposite-pair
netting, net formula, greedy matching/ties/non-optimality, and randomized invariants.
HTTP/MySQL tests cover memberships, validation, history, late joiners, different payers,
partial/full/excess payments, simplified routes, injected rollback, concurrent settlements,
concurrent membership/expense writes, consistent read snapshots, and group boundaries.
See [docs/verification.md](docs/verification.md) for checks actually executed.

## Stop and reset

Stop services while preserving the development database volume:

```powershell
docker compose --profile test down
```

The test service uses tmpfs, so its data disappears when its container stops. To recreate
only the disposable test database, leaving development data intact:

```powershell
docker compose --profile test rm -s -f test-db
docker compose --profile test up -d --wait test-db
```

**Destructive: the next command permanently deletes all development database data in
this Compose project's named volume**, as well as stopping/removing services:

```powershell
docker compose --profile test down -v
# Recreate clean demo services and data only if you intend that reset:
docker compose up --build -d --wait api
docker compose exec api python -m scripts.seed_demo
```

## Assumptions, tradeoffs, and future improvements

- INR only; display names need not be unique. No login or ownership model.
- All members participate in equal expenses; custom subsets may omit the payer.
- Membership is append-only through this API. Old splits are immutable.
- Financial correctness takes priority over maximizing one group's write concurrency.
- Bounded offset pagination is simple; cursor pagination is a future improvement.
- Ledger-derived balances keep one source of truth, with group-history memory/query cost.
- Greedy suggestions are practical and deterministic, with no exact optimum claim.
- No idempotency keys: after an ambiguous network failure, inspect history before retrying
  a financial POST. Future work should add idempotency and explicit reconciliation.
- No payment execution, multi-currency conversion, edit/delete/removal endpoints, or
  overpayment credits. Traceable reversal events would support future corrections.
- Before external deployment: add authentication, group authorization, managed secrets,
  HTTPS, operational monitoring, request limits, backups, and a dedicated migration step.
- At larger scale: measure query behavior, aggregate net balances in SQL, introduce
  reconciled projections only if needed, and address very large group payloads.

Review [docs/design-decisions.md](docs/design-decisions.md) and
[docs/interview-notes.md](docs/interview-notes.md) to explain the actual implementation
and its limitations in an interview.
