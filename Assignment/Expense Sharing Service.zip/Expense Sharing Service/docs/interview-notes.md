# Interview notes

## Explain the application in one minute

Users join groups and record expenses. The payer must be a member. Equal allocations
include every current member; custom allocations can select a subset. I save each
share once, store money in paise, and derive balances from shares and actual payments.
Suggestions simplify the net positions without changing the original ledger.

## Why FastAPI and MySQL?

FastAPI gives typed request/response contracts, Decimal validation through Pydantic,
async request handling, and interactive OpenAPI documentation without a frontend.
MySQL/InnoDB fits the relational data and provides foreign keys, check constraints,
atomic transactions, consistent reads, and row locking. SQLAlchemy keeps the queries
explicit; Alembic records schema evolution. Async I/O allows requests to yield while
waiting for the database; it does not eliminate locks or make CPU work faster.

## Why saved shares and integer paise?

Membership is current state; a split is historical financial data. Reusing today's
member list would charge new joiners for old dinners. The expense_splits table prevents
that. Integer paise gives exact sums. For 100 rupees among three people, ascending IDs
receive 33.34, 33.33, 33.33. Decimal string inputs avoid JSON floats; excess precision
is rejected rather than rounded away. The supported per-record ceiling is documented.

## How does concurrency work?

Every group-affecting write locks the same group row first. It then reads membership
or balances, validates, writes all rows, and commits. A second settlement waits before
reading its validation state. Sessions start no earlier reads. REPEATABLE READ makes
balance reads internally consistent; after waiting for a writer lock, the next ordinary
read starts a fresh snapshot. Holding a lock while calling external services would
be a mistake, so all work inside the transaction is local and brief.

Show `tests/integration/test_api.py`: the rollback test injects failure at split INSERT;
the concurrency test starts two payments while a separate transaction holds the group lock.

## Why derive balances?

A second independently mutable balance table needs coordinated updates and repair logic.
For this scope, the ledger is enough: paid minus allocated plus sent minus received.
Each financial event contributes equal opposite entries, so the sum stays zero.
Three group-filtered queries avoid N+1 reads. The tradeoff is reading the group's
entire financial history. At scale I would aggregate or introduce measured, reconciled
projections instead of adding them preemptively.

## What is the product enhancement?

Many direct debts are inconvenient to coordinate. If A owes B and B owes C, A can pay C
when the amounts match. Net positions express the real outstanding obligation independent
of original counterparties. Heap matching suggests practical transfers from the largest
debtor to the largest creditor in O(n log n), with ID tie-breaking for reproducibility.
It is advisory: users record only payments they actually made.

## Is greedy optimal?

No. It preserves exact net positions and uses at most n−1 payments, but does not search
all partitions for the fewest payments. See the explicit counterexample in design-decisions.md.
I would not describe it as a globally optimal algorithm. Exact optimization adds complexity
that is unnecessary for a clear, useful assignment feature.

## Why can pairwise balances remain after full settlement?

Pairwise balances net only the same pair's original obligations and real payments.
They do not rewrite history through third parties. A→B→C plus A paying C leaves a
zero-net cycle. Net balances are all zero and suggestions are empty. This is expected,
not an invitation to pay the cycle again. The response and documentation distinguish
the two views; settlement validation deliberately uses net positions.

## What are the tradeoffs and next steps?

- Group row locking is straightforward but serializes a very active group's writes.
- Offset pagination is readable; cursor pagination would scale better.
- No authentication is required here. A real deployment needs identity, membership
  authorization, secure configuration, auditability, and request controls.
- Idempotency keys are important before unreliable clients automatically retry money POSTs.
- Corrections should be traceable reversal events; don't overwrite historical expenses.
- Use a separate migration release step before running multiple API instances.
- Measure query size and latency before adding caching or financial projections.
- Integration tests use real MySQL and an isolated test user/database; SQLite would
  not exercise InnoDB locking and MySQL-specific constraints.

## Suggested walkthrough

1. Start Compose and open `/docs`.
2. Run `python -m scripts.seed_demo`; note the printed group IDs.
3. Show Goa's expense history: Priya is absent from the first dinner's saved shares.
4. Compare pairwise and net views. Show the custom allocation and the partial payment.
5. Show the chain group's single simplified suggestion in the demo output.
6. Show that after paying along that route, net balances are zero and suggestions empty,
   while the pairwise ledger retains its historical cycle.
7. Show migrations, the transaction boundary in the expense service, and test results.
