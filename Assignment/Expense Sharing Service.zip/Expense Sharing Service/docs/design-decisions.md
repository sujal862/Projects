# Design decisions

## Scope and API contract

The document body specifies an Expense Sharing Service, despite the PDF filename.
The implementation follows that body and the agreed specification. Python is the
preferred language in the PDF; MySQL, FastAPI, async SQLAlchemy, settlements,
custom splits, and Smart Settlement Suggestions follow the agreed choices.
No conflicting mandatory requirement was found. Suggested PDF routes and schema
were examples, so group-scoped responses and saved split rows refine them.

Names are labels, not identifiers. Two people named Mohit remain distinct users.
Names are trimmed, 1–100 characters; descriptions are trimmed, 1–500 characters.
Unknown request fields are rejected. Users can exist outside groups; groups start empty.
Adding the same membership twice returns 409. No edit/removal/deletion endpoints exist.

## Monetary contract

INR only. All monetary inputs are unsigned decimal **strings**, such as `"100.50"`.
JSON numbers are rejected so the JSON decoder cannot introduce binary floating point.
Decimal validates the boundary; all subsequent allocation, storage, netting, and matching
use integer paise. More than two fractional digits, even trailing zeros (`"1.000"`),
exponents, signs, spaces, NaN, infinity, and out-of-range values are rejected.
Maximum individual expense, payment, or share is INR 1,000,000,000.00
(100,000,000,000 paise). Expenses/payments must be positive; individual shares may be zero.
Derived totals use Python integers and may exceed that individual limit.
Outputs always use fixed two-decimal strings, including signed net amounts.

Equal splitting allocates quotient paise to every current member, then one extra
paisa to the first remainder members in ascending user ID order. Small amounts may
give some members a zero share. Custom allocations may include any nonempty subset,
with zero shares allowed, at least one positive share, no duplicates, and exact total.
The payer must be a member but may be absent from a custom allocation.

## Relational history and constraints

InnoDB tables represent users, groups, memberships, expenses, saved shares, and settlements.
Composite membership and split primary keys enforce uniqueness. Foreign keys use
RESTRICT to prevent deleting referenced financial history. Composite foreign keys
also enforce that expense payers and settlement participants are group members.
Check constraints bound stored amounts and prevent self-settlements. Split membership
and cross-row sum equality are validated by the service inside the locked transaction;
a MySQL row check cannot express the sum across all split rows. Direct SQL writes are
outside the supported API contract and could bypass those service invariants.

Stored shares are the historical participants. Later membership additions never alter
past allocations. No derived balances table means no separate balance state can drift
from the ledger. Models use explicit queries rather than lazy ORM relationships,
which keeps async I/O and query counts visible.

Timestamps are generated in UTC, stored as MySQL DATETIME(6) without an offset, and
returned as timezone-aware ISO 8601 UTC (`Z`). Connections explicitly set UTC.
All writes go through this application, so application-generated timestamps suffice
for this scope. IDs, rather than timestamps, provide deterministic list ordering.

## Transactions and concurrency

Every service operation owns an explicit `session.begin()` block. Dependencies yield
fresh sessions and execute no queries first. No route commits independently.
Adding a member, creating an expense, and recording a settlement first acquire
`SELECT groups ... FOR UPDATE`, then read dependent state, validate, flush, and commit.
Every group mutation uses this same order. A failed split insert rolls back the expense too.

MySQL REPEATABLE READ provides consistent multi-query balance/suggestion snapshots.
For writers, the first statement is a locking (current) read. It does not establish
the consistent-read snapshot. Dependent ordinary SELECTs execute only after the lock
is acquired, so a waiting settlement sees the earlier writer's committed payment.
The concurrent integration test holds the group lock, launches two overlapping
payments, then verifies exactly one excessive combined payment is accepted.

This serializes writes per group and limits throughput for a very busy group; it is
simple to reason about for a trip-sized service. Reads do not lock the group. There
are no automatic retries or idempotency keys. Clients must reconcile history after
an ambiguous network failure rather than blindly retrying a financial POST.
Migrations run before Uvicorn for a single-instance demo. MySQL DDL is not generally
transactional: a failed migration needs inspection/recovery, not blind stamping.

## Balance semantics

For each non-payer split, the participant owes that saved share to the payer.
Opposite obligations cancel within each pair; unrelated third parties are not used
to simplify this historical view. A recorded payment adds an opposite pairwise entry.

Net = expenses paid − shares allocated + payments sent − payments received.
The self-share cancels the corresponding part of the payer's expense. Positive net
means should receive; negative means should pay. Summing every member yields zero.
Settlement validation uses the sender's negative and recipient's positive net positions,
not a required original direct debt. Partial payments are accepted up to the smaller
outstanding position. This records real payments; it never calls a bank.

If A owes B 500 and B owes C 500, A can pay C 500. All net balances become zero,
while the pairwise ledger then contains A→B, B→C, C→A. This zero-net cycle describes
the original ledger plus payment; it is not a demand for three more payments.
Use net balances and suggestions to determine what remains to be paid. A settled
group has no suggestions even if such a cycle remains.

## Smart Settlement Suggestions

The user problem is coordination across many interconnected debts. Build max-heaps
of negative and positive net positions, repeatedly match the largest debtor to the
largest creditor, transfer the smaller remainder, and reinsert any leftover position.
Equal amounts break ties using ascending user ID. All steps use integer paise.
Matching is O(n log n) time and O(n) space after calculating balances, with at most
n−1 transfers for a nonempty unsettled group. It preserves each member's net position,
may change who pays whom, and does not guarantee the global minimum transfer count
or improvement over every alternative. Suggestions have no persistence or side effects.

For a concrete non-optimal case: debtors owe 800, 700, 600, 500 and creditors are owed
1500 and 1100. Greedy uses 5 payments, while (800+700→1500) and (600+500→1100)
use 4. Exact optimization is outside scope.

## Query scope and growth

Balance loading runs three group-filtered queries (members, joined split obligations,
settlements), plus the group existence query. This is O(n + s + t) rows in memory for
n members, s saved shares, and t settlements; there is no per-expense/per-user query.
Expense history fetches one page and all its split rows in one extra query.
Growing list endpoints use bounded limit (1–100, default 20), offset, ascending ID,
and `has_more`, fetching one extra row. Membership pages sort by user ID.
Balances/suggestions intentionally return the full current group state, not a partial ledger.

At larger scale, aggregate net positions in SQL, use cursor pagination, and consider
reconciled projections only after measuring. Large individual groups and custom split
payloads are not capped by an application-level participant limit in this assignment.

## Operational boundaries

This demo has no authentication, authorization, idempotency, payment execution,
multi-currency support, member removal, or expense corrections. Compose binds ports
to localhost and uses synthetic credentials; it is not a production deployment.
The API runs as a non-root OS user, the database app user is scoped to its database,
and client errors omit raw input, SQL, credentials, and stack traces.
Liveness is process-only; readiness executes SELECT 1 and does not certify migration
currency or every table. No production security/performance guarantee is claimed.

Integration cleanup requires an explicit TEST_DATABASE_URL with the fixed test
database and test user, distinct from the configured development database. Compose
provides that user only on a separate disposable test service. Tests run serially;
parallel test workers sharing that database are unsupported.
