# Executed verification

Checked on 2026-10-22 in the supplied Windows workspace, with local Python 3.11.9,
Docker Engine 29.6.2, Python 3.11.14 in the API container, and real MySQL 8.4.8/InnoDB.
These are local functional checks, not production performance or security certification.

| Check | Result |
| --- | --- |
| `python -m pytest -q` with explicit isolated TEST_DATABASE_URL | 57 passed: 37 unit, 20 MySQL integration |
| `python -m ruff check .` | Passed |
| `python -m ruff format --check .` | Passed |
| `python -m pip check` (local and container) | No broken requirements |
| `docker compose up --build -d --wait api` | Image built; API and authenticated database health checks passed |
| `/health`, `/ready`, `/openapi.json` | Served successfully |
| `docker compose exec api python -m alembic check` | No new upgrade operations detected |
| Alembic downgrade to base, upgrade to head on disposable test database | Passed; current revision 0001 |
| `python -m scripts.seed_demo` through real HTTP API | Passed its history and simplified-settlement assertions |
| Newman 6.2.1 with supplied collection/environment | 34 requests, 43 assertions, zero failures |
| API container `id` | Runs as appuser, UID 1000 |

Integration checks exercise:

- User/group/member creation/listing, pagination, duplicate names and memberships.
- Expense persistence, deterministic remainders, custom subsets and zero shares.
- Missing/invalid groups, payers, participants, amounts, totals, and conflicting split input.
- Historical shares after a late member joins, and multiple expense payers.
- Partial/full settlements, sender/recipient net directions, amount limits on both sides.
- Simplified-route payment and zero remaining suggestions despite a pairwise history cycle.
- Failure injected during split insertion, verifying both expense and split rollback.
- Overlapping settlement requests blocked by the same group row lock; one is rejected
  after the first changes the outstanding balance.
- Expense blocked behind a membership write, then using the newly committed membership.
- A reader retaining a consistent snapshot during a concurrent expense write.
- Balances remaining isolated between groups.

Pure tests include 250 seeded randomized scenarios checking exact share totals, the
net formula and zero-sum invariant, positive/non-self suggestions, the n−1 payment
bound, and zero final balances after applying every suggestion. A greedy counterexample
explicitly demonstrates that the algorithm is not globally optimal.

## Resolved environment and implementation issues

The host refused binding port 3306. Development MySQL now defaults to host port 3308;
the container network still uses 3306. Test MySQL uses its own service on port 3307.
There are no remaining Docker/MySQL blockers in this environment.

The first migration attempt exposed duplicated automatic names for settlement membership
foreign keys; both now have explicit names. The disposable test database was recreated,
then migration, schema comparison, and round-trip migration checks passed.

Initial Postman scripts collided with Newman sandbox globals (`data`/`responseBody`).
Scripts now run in function scope; the full collection subsequently passed. Newman
emits an upstream Node.js deprecation warning on Node 24; it did not fail the run.

`docs/demo-output.json` contains a captured successful seed run with synthetic IDs.
IDs/timestamps will differ in a new database. The demo and Postman runs append data;
they are not performance benchmarks. The Postman desktop UI was not manually exercised;
its actual collection scripts were executed through Newman.

No GitHub push, publication, HR email, or assignment submission was performed.
